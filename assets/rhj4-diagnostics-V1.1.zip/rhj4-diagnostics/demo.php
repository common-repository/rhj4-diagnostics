<p>Open browser console window to see outputs.</p>
<div>
    <table class='rhj4_plugins_demo'>
        <tr>
            <td class='rhj4_plugins_label'>Source:</td><td><input id='source' type='text' placeholder='DIAG: ' /></td><td>Enter source string</td>
        </tr>
        <tr>
            <td class='rhj4_plugins_label'>Message:</td><td><input id='message' type='text' placeholder='diagnostic message' /></td>
            <td>Enter message text</td>
        </tr>
        <tr class=' path_selector'>
            <td class='rhj4_plugins_label'>Using:</td>
            <td><input type='radio' name='path' id='useBrowser' value='Browser' checked/>Browser<input type='radio' name='path' id='useServer' value='Server'  />Server</td>
            <td>Select Path</td></tr>
        <tr class='output_selector'><td class='rhj4_plugins_label'>Output 1:</td><td><input type='text' id='output1' value='rhj4_log' /></td><td>Select output(s)</td></tr>
        <tr class='output_selector'><td class='rhj4_plugins_label'>Output 2:</td><td><input type='text' id='output2' value='my_diagnostic_test_output' /></td></tr>
        <tr class='output_selector'><td class='rhj4_plugins_label'>Output 3:</td><td><input type='text' id='output3' value='my_other_test_output' /></td></tr>
    </table>
    <table class='rhj4_plugins_buttons'>
        <tr><td> 
            <input type='button' id='generate_button' value='Generate' onclick='diagnostic_submit();return false;' />
            <input type='button' id='show_button' value='Show' onclick='diagnostic_show();return false;' />
            <input type='button' id='clear_button' value='Clear' onclick='diagnostic_clear();return false;' />
        </td></tr>
    </table>
</div>

