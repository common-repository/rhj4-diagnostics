/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


function diagnostic_submit() {
    jQuery.notification.erase();
    var ok = true;
    
    var source = jQuery('#source').val();
    if (source.trim() === '') {
        jQuery.notification({ notification: "Message source is empty", type: "error", sticky: true, queue: false });
        ok = false;
    }

    var message = jQuery('#message').val();
    if (message.trim() === '') {
        jQuery.notification({ notification: "Message text is empty", type: "error", sticky: true, queue: false });
        ok = false;
    }
    
    if (ok === false) {
        return;
    }
    
    var path = jQuery('input[name=path]:checked').val();
    switch(path) {
        case 'Browser':
            jQuery.diagnostic(message);
            message = "The following line will appear in the browser console:<br /><br />" + source + message;
            jQuery.notification({ notification: message, type: "data", sticky: true, queue: false });
            jQuery.notification({ notification: "See browser console", type: "confirmation", sticky: false, queue: false });
            break;
            
        case 'Server':
            jQuery.diagnostic(message);
            jQuery.notification({ notification: source + message, type: "data", sticky: true, queue: false });
            jQuery.notification({ notification: "Message written to server log", type: "confirmation", sticky: false, queue: false });
            break;
            
        default:
            jQuery.notification({ notification: "Select path", type: "error", sticky: true, queue: false });
            break;
    }
    
//    var output1 = jQuery('#output1').val().trim();
//    if (output1.length > 0) {
//        if (jQuery.isFunction(output1)) {
//            jQuery.diagnostic({ message: message, source: source, output: output1(message) });
//        } else {
//            jQuery.notification({ notification: output1 + " is not a function", type: "error", sticky: true, queue: false });
//            ok = false;
//        }
//    }
//    
//    var output2 = jQuery('#output2').val().trim();
//    if (output2.length > 0) {
//        if (jQuery.isFunction(output2)) {
//            jQuery.diagnostic({ message: message, source: source, output: output2(message) });
//        } else {
//            jQuery.notification({ notification: output2 + " is not a function", type: "error", sticky: true, queue: false });
//            ok = false;
//        }
//    }
//    
//    var output3 = jQuery('#output3').val().trim();
//    if (output1.length > 0) {
//        if (jQuery.isFunction(output3)) {
//            jQuery.diagnostic({ message: message, source: source, output: output3(message) });
//        } else {
//            jQuery.notification({ notification: output3 + " is not a function", type: "error", sticky: true, queue: false });
//            ok = false;
//        }
//    }
    
    
    //  Now update the displays of the various log files
    
}

function diagnostic_show() {
    diagnostic_submit();
//    var source = jQuery('#source').val();
//    var message = jQuery('#message').val();
//    jQuery.notification({ notification: source + message, type: "confirmation", sticky: true, queue: false });
}

function diagnostic_clear() {
    jQuery.notification.erase();
}

jQuery(document).ready(function (jQuery) {
    jQuery.diagnostic('Diagnostics Demo loaded','DEMO: ');
    jQuery('.output_selector').hide();
    jQuery('.path_selector').hide(); 
    jQuery('#generate_button').hide(); 
    
    jQuery('#useBrowser').click(function() {
       jQuery('.output_selector').hide();
    });
    
    jQuery('#useServer').click(function() {
       jQuery('.output_selector').show();
    });
    
});